infile <- "D:/Users/Laurent/Dropbox/CMPG/Courses/MolPopGenPraktikum/MolPopGen practicals 2015/Data Analysed/Day 4/HGDP_783_STR_NumberCoded.res/HGDP_783_STR_NumberCoded.xml"
outfiles <- "D:/Users/Laurent/Dropbox/CMPG/Courses/MolPopGenPraktikum/MolPopGen practicals 2015/Data Analysed/Day 4/HGDP_783_STR_NumberCoded.res/Graphics/"
sourcePath <- "D:/Users/Laurent/Dropbox/Programs/GitHub/arlequin-dev/Rfunctions/"

source(paste(sourcePath, "parseArlequin.r", sep="") )
parseArlequin(infile, outfiles, sourcePath)
